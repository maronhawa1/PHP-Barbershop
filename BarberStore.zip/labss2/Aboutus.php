<?php include 'navbar.php'; ?>

<div class="jumbotron">
  <h1 class="display-4">Hello, Welcome To Our HairShop!</h1>
 
  <hr class="my-4">
  <p>The company was founded in 2023. The company's goal is to sell products related to hair,including appointments, so that you can find all the products used for styling and hair care, and the prices of the products are not expensive.</p>
  <p> Our location :</p>
  <p><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d53711.065910344914!2d35.28981745!3d32.714179!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x151c4e7cf16c0fff%3A0xd2385b30c1275dd6!2z2KfZhNmG2KfYtdix2Kk!5e0!3m2!1sar!2sil!4v1673817001291!5m2!1sar!2sil" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe></p>
  <a class="btn btn-primary btn-lg" href="login.php" role="btn btn-dark">For login</a>
</div>
