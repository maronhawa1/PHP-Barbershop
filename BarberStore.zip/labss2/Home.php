<?php include 'navbar.php';
      include 'DBconnect.php';
?>

<style>
h5{
    color:white;
    text-align:center;
   font-size:50px;
}
p{
    color:white;
    font-size:25px;
   
}

    </style>
    <form method="POST">
<div class="card text-bg-dark">
  <img src="https://www.soundproofcow.com/wp-content/uploads/2020/06/salon.jpg" height="350px" class="card-img" alt="...">
  <div class="card-img-overlay">
    <h5 class="card-title">Welcome To Our HairShop</h5>
    <center>
    <p class="card-text">You can here find all the hair equipments</p>
    
     <p class="card-text"> <input type="submit" name="shop" class="btn btn-white" value="Shop Now!" /> </small></p>

</div>
</div>
<div class="card bg-dark text-white">
            <img src="./images/BARBER.jpg" height="350px" class="card-img" alt="...">
            <div class="card-img-overlay text-center">
                
               
               
                   
                    <!-- <a href="./user/shop.php" class="btn btn-dark">
            <i class="fas fa-envelope"></i> Contact us!
        </a> -->
                </a>
            </div>
        </div>
</form>