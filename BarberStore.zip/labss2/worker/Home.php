<?php 
include './index.php'

?>
<style>
h5{
    color:white;
    text-align:center;
   font-size:50px;
}
p{
    color:white;
    font-size:25px;
   
}
a:link { text-decoration: none; 
color: black;}


a:visited { text-decoration: none; color: black;}


a:hover { text-decoration: none; color: black;}


a:active { text-decoration: none;color: black; }



    </style>
    <form method="POST">
<div class="card text-bg-dark">
  <img src="https://www.soundproofcow.com/wp-content/uploads/2020/06/salon.jpg" height="350px" class="card-img" alt="...">
  <div class="card-img-overlay">
  <h5 class="card-title">Welcome Barber</h5>
    <center>
    <p class="card-text">Here you can find your appointments</p>
    
    <button class="btn btn-white">   <a href="./app.php" >My Appointments</a></button>
    

</div>
</div>
<div class="card bg-dark text-white">
            <img src="../images/BARBER.jpg" height="350px" class="card-img" alt="...">
            <div class="card-img-overlay text-center">
           
            </div>
        </div>
</form>