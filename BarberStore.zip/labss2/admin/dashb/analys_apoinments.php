<?php
include '../DBconnect2.php';
session_start();
$appointments_query = "SELECT id_userW, COUNT(*) AS appointment_count FROM history_of_queues GROUP BY id_userW";
$appointments_result = mysqli_query($con, $appointments_query);

$barber_appointments = array();
while ($row = mysqli_fetch_assoc($appointments_result)) {
    $barber_id = $row['id_userW'];
    $appointment_count = $row['appointment_count'];

    $barber_appointments[$barber_id] = $appointment_count;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>My profile</title>
  <!-- Favicon -->
  <link rel="shortcut icon" href="./img/svg/logo.svg" type="image/x-icon">
  <!-- Custom styles -->
  <link rel="stylesheet" href="./css/style.min.css">
  <style>
   img {
  border-radius: 50%;
}
.profile {

  inline-size: 30%;
  border-block-start-width: 10px;
  border-block-start-style: solid;
  border-block-start-color: orange;
    border-block-end-style: solid;
  border-block-end-width: 10px;
}
p {
  font-weight: 800;
}

  </style>
</head>

<body>
  <div class="layer"></div>
  <!-- ! Body -->
  <a class="skip-link sr-only" href="#skip-target">Skip to content</a>
  <div class="page-flex">
    <?php include 'sidebar.php' ?>
    <div class="main-wrapper">
      <!-- ! Main nav -->
      <nav class="main-nav--bg">
        <div class="container main-nav">
          <div class="main-nav-start">
       
              <!-- Add your search input or content here -->
            </div>
            <?php include 'navbar.php';  ?>
            <!-- ! Main -->
            <main class="main users chart-page" id="skip-target">
              <div class="container">
                <center>
                  <h2 class="main-title"> Apointments Analys</h2>

                  <?php
                  $date_exist = 0;
                  if (isset($_POST['select'])) {
                    $date = trim($_POST['date']);
                    $sql = "SELECT * FROM history_of_queues WHERE date='$date'";
                    $result = mysqli_query($con, $sql);
                    $apoinments = array();
                    $time = array();
                    while ($row = mysqli_fetch_array($result)) {
                      $username = "SELECT * FROM userss WHERE ID_u=" . $row['id_userW'];
                      $res_username = mysqli_query($con, $username);
                      $nameOfUser = mysqli_fetch_assoc($res_username);

                      $apoinments[] =  $nameOfUser['name'];
                      $time[] = $row['time'];

                      // Set date_exist to 1 if there are results for the selected date
                      $date_exist = 1;
                    }
                  }
                  ?>

                  <div style="width:60%;text-align:center">
                    <h2 class="page-header">Appointments Reports for day <?php echo $date; ?></h2>
                    <form method="post">
                      <input type="date" name="date" placeholder="00/00/2022">
                      <input type="submit" value="Select date" name="select">
                    </form>
                    <?php
                    if ($date_exist) {
                      ?>
                      <p><canvas id="chartjs_bar"></canvas></p>
                      <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
                      <script type="text/javascript">
                        var barberNames = {};
    <?php
    foreach ($barber_appointments as $barber_id => $appointment_count) {
        $barber_query = "SELECT name FROM userss WHERE ID_u = $barber_id";
        $barber_result = mysqli_query($con, $barber_query);
        $barber_name = mysqli_fetch_assoc($barber_result)['name'];
        echo "barberNames[$barber_id] = '$barber_name';\n";
    }
    ?>
                        var barber_appointments = <?php echo json_encode($barber_appointments); ?>;
    var barbers = <?php echo json_encode(array_keys($barber_appointments)); ?>;
    var ctx = document.getElementById("chartjs_bar").getContext('2d');
    var myChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: barbers.map(barber_id => barberNames[barber_id] || 'Unknown Barber'),
            datasets: [{
                backgroundColor: [
                    "#5969aa",
                    "#ff407b",
                    "#331523",
                    "#ffc750"
                ],
                data: barbers.map(barber_id => barber_appointments[barber_id] || 0),
            }]
        },
        options: {
            tooltips: {
                callbacks: {
                    title: function (tooltipItems) {
                        return tooltipItems[0].label;
                    },
                    label: function (tooltipItem, data) {
                        var dataset = data.datasets[tooltipItem.datasetIndex];
                        var currentValue = dataset.data[tooltipItem.index];
                        return 'Count: ' + currentValue;
                    }
                }
            },
            legend: {
                display: true,
                position: 'bottom',
                labels: {
                    fontColor: '#71748d',
                    fontFamily: 'Circular Std Book',
                    fontSize: 14,
                }
            }
        }
    });

                      </script>
                    <?php
                    } else {
                      ?>
                      <p>No Appointments exist on this date</p>
                    <?php
                    }
                    ?>
                  </div>
                </center>
              </div>
            </main>
            <!-- ! Footer -->
          </div>
        </div>
      </nav>
    </div>
  </div>
  <!-- Chart library -->
  <script src="./plugins/chart.min.js"></script>
  <!-- Icons library -->
  <script src="plugins/feather.min.js"></script>
  <!-- Custom scripts -->
  <script src="js/script.js"></script>
</body>

</html>
